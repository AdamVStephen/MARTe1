
EasyExp, Scandir, EasyExp Synthesis Unit test using Google test
Sep 2015, Masaharu Goto

# Running the test

  $ cd $CINTSYSDIR/lib/EasyExp/gtest/test1/build
  $ cmake ..
  $ make
  $ ./test1


