makecint -mk makecyg -dl excel.dll -H Excel.h ReadF.h RegE.h Stat.h Value.h -C++ Excel.cxx ReadF.cxx RegE.cxx Stat.cxx Value.cxx

