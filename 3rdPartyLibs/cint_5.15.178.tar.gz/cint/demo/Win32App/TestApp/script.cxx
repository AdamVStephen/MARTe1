// script.cxx
// 
//  This source is interpreted by cint. Change this file as you want
// and re-run the script by 'File->cint' pull-down menu. There is no
// need to compile this source at all.
//
#include <windows.h>

void main() {
  MessageBox(0,"Caption","Message",MB_OK);
}
