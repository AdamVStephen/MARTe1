/* =======================================================
	Simple Win32API Application for Drawing Graphics.

	WndProc.h: Header file for WndProc.c
	Last modified Time-stamp: <02/01/13 09:48:12 hata>            
	Proposed by K.Hata <kazuhiko.hata@nifty.ne.jp>
========================================================== */

extern LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);

