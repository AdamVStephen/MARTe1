#include <GL/glut.h>
#include "display0.dll"

void f() {
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
   glutInitWindowSize (250, 250);
   glutInitWindowPosition (100, 100);
   glutCreateWindow ("hello");
   glClearColor (0.0, 0.0, 0.0, 0.0);

   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
	
   glutDisplayFunc(display);
   printf("!!! Hit ctl-C twice and type 'q' to quit\n");
   glutMainLoop();
}

int main() {
  f();
  return 0;
}
