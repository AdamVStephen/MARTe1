#include <iostream.h>
class HelloWorld {  
 public:           
  HelloWorld() { cout << "Hello World\n" ; }   
} Main; 
main() {}

