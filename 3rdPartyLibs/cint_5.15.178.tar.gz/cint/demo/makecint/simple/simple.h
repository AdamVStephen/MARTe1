
#ifndef SIMPLE_H
#define SIMPLE_H

#include <stdio.h>

class Simple {
 public:
  Simple() {}
  void f1(int a,double b) ;
};

void f1(int a,double b) ;

#endif
