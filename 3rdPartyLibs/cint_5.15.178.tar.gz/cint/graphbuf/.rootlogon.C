{
  G__loadfile("rootgraphdaemon.h");
  loop();
}
