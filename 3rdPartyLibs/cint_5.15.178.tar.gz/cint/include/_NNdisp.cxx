
#include <CSV.h>
#include <NeuralNet.h>

int main(int argc,char **argv) {
  for(int i=1;i<argc;i++) NNdisp(argv[i]);
}
