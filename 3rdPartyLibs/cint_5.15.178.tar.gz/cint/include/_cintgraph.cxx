#include <NVector.h>

int main(int argc,char **argv) {
  for(int i=1;i<argc;i++) cintgraph_command(argv[i]);
}

