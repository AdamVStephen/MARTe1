#ifndef G__BOOLEAN_H
#define G__BOOLEAN_H

#ifdef G__OLDIMPLEMENRTATION1604
#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef boolean
typedef int boolean;
#endif
#endif

#endif
