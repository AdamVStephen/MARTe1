/*********************************************************************
* stdiostream.h
*
*********************************************************************/

#ifndef G__STDIOSTREAM_H
#define G__STDIOSTREAM_H

#include <iostream.h>

#endif
