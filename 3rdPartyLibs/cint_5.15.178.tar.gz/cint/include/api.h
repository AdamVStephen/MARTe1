#ifndef G__ERTTI_H

#include <ertti.h>

#endif
