#ifndef G__LOCALE_H
#define G__LOCALE_H
#ifndef G__STDSTRUCT
#pragma setstdstruct
#endif
#define 	LC_ALL (0)
#define 	LC_COLLATE (1)
#define 	LC_CTYPE (2)
#define 	LC_MONETARY (3)
#define 	LC_NUMERIC (4)
#define 	LC_TIME (5)
#endif
